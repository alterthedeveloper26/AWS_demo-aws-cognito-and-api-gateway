export const STAGING = 'staging';
export const PRODUCTION = 'production';
export const UAT = 'uat';
export const CORRELATION_ID_HEADER = 'x-correlation-id';
