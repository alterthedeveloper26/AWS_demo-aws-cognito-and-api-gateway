export const sensitiveFields = [
  'password',
  'newPin',
  'currentPin',
  'token',
  'newPassword',
  'currentPassword',
  'documentNumber'
];
