export const generateCustomerName = (
  firstName: string,
  lastName: string
): string => `${firstName} ${lastName}`;
