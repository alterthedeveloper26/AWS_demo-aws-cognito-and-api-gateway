export class ApiResponse<T = unknown> {
  success: boolean;

  correlationId?: string;

  result?: T;

  message?: string | string[];
}
