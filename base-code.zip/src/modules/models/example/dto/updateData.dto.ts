import { ApiProperty } from '@nestjs/swagger';

export class UpdateDataDto {
  @ApiProperty()
  someField: string;
}
