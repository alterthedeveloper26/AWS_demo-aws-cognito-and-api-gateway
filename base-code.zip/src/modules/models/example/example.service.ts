import { ApiResponse } from './../../../base/base.response';
import { CreateDataDto } from './dto/createData.dto';
import { Injectable } from '@nestjs/common';
import { Example } from '~models/example/entity/example.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class ExampleService {
  constructor(
    @InjectRepository(Example)
    private readonly exampleRepository: Repository<Example>
  ) {}

  async postSomething(body: CreateDataDto) {
    // handle logic here
    let tmp = await this.exampleRepository.save(body);
    return {
      success: true
    };
  }

  async getSomething(): Promise<ApiResponse<Example[]>> {
    const res = await this.exampleRepository.find();
    return {
      success: true,
      result: res
    };
  }

  async updateData(body) {
    return {
      success: true
    };
  }
}
