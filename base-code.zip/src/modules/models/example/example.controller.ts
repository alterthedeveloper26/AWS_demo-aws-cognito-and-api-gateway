import { ApiResponse } from './../../../base/base.response';
import { CreateDataDto } from './dto/createData.dto';
import { UpdateDataDto } from './dto/updateData.dto';
import { ExampleService } from '~models/example/example.service';
import { Body, Controller, Get, Post, Put } from '@nestjs/common';
import { ApiResponseSchema } from '~common/decorator/api-response.decorator';
import { ApiTags } from '@nestjs/swagger';
import { Example } from '~models/example/entity/example.entity';

@ApiTags('Example')
@Controller('example')
export class ExampleController {
  constructor(protected readonly exampleService: ExampleService) {}

  @Post('')
  @ApiResponseSchema()
  async postSomething(@Body() body: CreateDataDto): Promise<ApiResponse> {
    return this.exampleService.postSomething(body);
  }

  @Get('/list')
  @ApiResponseSchema()
  async getSomething(): Promise<ApiResponse<Example[]>> {
    return this.exampleService.getSomething();
  }

  @Put('')
  @ApiResponseSchema()
  async updateData(@Body() body: UpdateDataDto): Promise<ApiResponse> {
    return this.exampleService.updateData(body);
  }
}
