import { Module } from '@nestjs/common';
import { ExampleModule } from '~models/example/example.module';

@Module({
  imports: [ExampleModule]
})
export class ModelsModule {}
