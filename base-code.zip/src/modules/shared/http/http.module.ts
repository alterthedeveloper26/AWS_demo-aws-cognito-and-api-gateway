import { HttpModule as BuiltInHttpModule } from '@nestjs/axios';
import { DynamicModule, Global, Module } from '@nestjs/common';

import { httpServiceConfig } from '~/config';
import { InternalApiService } from '~shared/http/internal-api.service';

@Global()
@Module({})
export class HttpModule {
  public static register(serviceName: string, baseUrl: string): DynamicModule {
    return {
      module: HttpModule,
      imports: [
        BuiltInHttpModule.register({
          timeout: httpServiceConfig.timeout,
          baseURL: baseUrl
        })
      ],
      providers: [
        {
          provide: serviceName,
          useExisting: InternalApiService,
          useClass: InternalApiService
        }
      ],
      exports: [serviceName]
    };
  }
}
