import { createLogger, Logger, transports } from 'winston';
import { Syslog, SyslogTransportOptions } from 'winston-syslog';

import { environment as env, papertrailConfig, serviceName } from '~/config';
import { PRODUCTION } from '~common/constants/environments';

const getDefaultLevel = (environment: string): string => {
  if (!environment) {
    throw Error('ArgumentError: environment');
  }

  return environment === PRODUCTION ? 'info' : 'debug';
};
const options: SyslogTransportOptions = {
  protocol: 'tls4',
  host: papertrailConfig.host,
  port: papertrailConfig.port,
  app_name: papertrailConfig.appName,
  localhost: `${serviceName}-${env}`,
  eol: '\n'
};

const initLogger = (
  environment: string,
  level = getDefaultLevel(environment)
): Logger =>
  createLogger({
    level,
    transports: [new transports.Console(), new Syslog(options)]
  });

export { initLogger };
